package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.ChatMessage
import com.example.data.model.MerkopMode
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ConversationRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createConversation_authenticatedOwner_createsAndReadsBack() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repo = ConversationRepository(firestore)

        val convId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createConversation("Merkop Test", MerkopMode.GENERAL).getOrThrow()
        }
        assertTrue(convId.isNotEmpty())

        val fetched = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.getConversation(aliceUid, convId).getOrThrow()
        }
        assertNotNull(fetched)
        assertEquals("Merkop Test", fetched?.title)
        assertEquals(MerkopMode.GENERAL.id, fetched?.mode)
    }

    @Test
    fun addMessageAndObserve_authenticatedOwner_emitsMessages() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repo = ConversationRepository(firestore)

        val convId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createConversation("İlk Sohbet", MerkopMode.CODER).getOrThrow()
        }
        val msgId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.addMessageAndUpdateConversation(
                conversationId = convId,
                role = ChatMessage.ROLE_USER,
                text = "Merhaba Merkop!",
                hasImage = false,
                newTitleIfFirst = "Merhaba Merkop!",
                newMessageCount = 1L
            ).getOrThrow()
        }
        assertTrue(msgId.isNotEmpty())

        val messages = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeMessages(aliceUid, convId).first { list -> list.any { it.id == msgId } }
        }
        assertEquals(1, messages.size)
        assertEquals("Merhaba Merkop!", messages.first().text)
    }

    @Test
    fun observeConversations_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = ConversationRepository(firestore)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createConversation("Gizli Sohbet", MerkopMode.GENERAL).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = ConversationRepository(firestore)
        val exception = runCatching {
            withTimeout(FLOW_TIMEOUT_MS) { bobRepo.observeConversations(aliceUid).first() }
        }.exceptionOrNull()

        assertNotNull("Expected PERMISSION_DENIED exception", exception)
        val firestoreException = checkNotNull(exception?.unwrapFirestoreException()) {
            "Expected nested FirebaseFirestoreException, got $exception"
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException.code)
    }

    @Test
    fun observeConversations_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        auth.signOut()
        val repo = ConversationRepository(firestore)

        val exception = runCatching {
            withTimeout(FLOW_TIMEOUT_MS) { repo.observeConversations(aliceUid).first() }
        }.exceptionOrNull()

        assertNotNull("Expected PERMISSION_DENIED exception", exception)
        val firestoreException = checkNotNull(exception?.unwrapFirestoreException()) {
            "Expected nested FirebaseFirestoreException, got $exception"
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException.code)
    }

    private companion object {
        const val ALICE_EMAIL = "alice_merkop@test.com"
        const val BOB_EMAIL = "bob_merkop@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
