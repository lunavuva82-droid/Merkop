package com.example.util

import android.content.Context
import android.content.Intent
import android.text.Html
import androidx.core.content.FileProvider
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.MerkopMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object HtmlTranscriptExporter {

    fun buildSingleFileHtml(
        conversation: Conversation,
        messages: List<ChatMessage>
    ): String {
        val titleEscaped = Html.escapeHtml(conversation.title.ifBlank { "Merkop Sohbeti" })
        val modeLabel = Html.escapeHtml(MerkopMode.fromId(conversation.mode).label)
        val dateFormat = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.forLanguageTag("tr"))
        val exportedAt = dateFormat.format(Date())

        val messagesHtml = buildString {
            for (msg in messages) {
                val isUser = msg.role == ChatMessage.ROLE_USER
                val roleLabel = if (isUser) "Sen" else "Merkop"
                val rowClass = if (isUser) "msg user" else "msg model"
                val timeStr = msg.createdAt?.toDate()?.let { dateFormat.format(it) } ?: ""
                val bodyEscaped = Html.escapeHtml(msg.text).replace("\n", "<br>")
                append(
                    """
                    <div class="$rowClass">
                      <div class="meta"><strong>$roleLabel</strong><span>$timeStr</span></div>
                      <div class="bubble">$bodyEscaped</div>
                    </div>
                    """.trimIndent()
                )
            }
        }

        return """
            <!DOCTYPE html>
            <html lang="tr">
            <head>
              <meta charset="UTF-8" />
              <meta name="viewport" content="width=device-width, initial-scale=1.0" />
              <title>$titleEscaped — Merkop AI</title>
              <style>
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #FFFAF6; color: #1F1916; margin: 0; padding: 24px 16px; }
                .container { max-width: 760px; margin: 0 auto; background: #FFFFFF; border: 1px solid #FFCFA8; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(255,107,0,0.08); }
                header { background: linear-gradient(135deg, #FF6B00, #FF852D); color: #FFFFFF; padding: 20px 24px; }
                header h1 { margin: 0 0 6px; font-size: 20px; }
                header p { margin: 0; font-size: 13px; opacity: 0.92; }
                .chat { padding: 20px; display: flex; flex-direction: column; gap: 14px; }
                .msg { display: flex; flex-direction: column; max-width: 85%; }
                .msg.user { align-self: flex-end; align-items: flex-end; }
                .msg.model { align-self: flex-start; align-items: flex-start; }
                .meta { font-size: 11px; color: #6B5B51; margin-bottom: 4px; display: flex; gap: 8px; }
                .bubble { padding: 12px 16px; border-radius: 16px; line-height: 1.5; font-size: 15px; }
                .msg.user .bubble { background: #FF6B00; color: #FFFFFF; border-bottom-right-radius: 4px; }
                .msg.model .bubble { background: #FFF4EC; color: #1F1916; border: 1px solid #FFD6B8; border-bottom-left-radius: 4px; }
                footer { padding: 14px 24px; font-size: 12px; color: #6B5B51; border-top: 1px solid #FFF0E4; text-align: center; }
              </style>
            </head>
            <body>
              <div class="container">
                <header>
                  <h1>$titleEscaped</h1>
                  <p>Merkop AI • Mod: $modeLabel • Dışa Aktarım: $exportedAt</p>
                </header>
                <div class="chat">$messagesHtml</div>
                <footer>Merkop AI &bull; Firebase ile oluşturuldu</footer>
              </div>
            </body>
            </html>
        """.trimIndent()
    }

    fun shareHtmlTranscript(
        context: Context,
        conversation: Conversation,
        messages: List<ChatMessage>
    ) {
        val html = buildSingleFileHtml(conversation, messages)
        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportsDir, "merkop-sohbet.html")
        file.writeText(html, Charsets.UTF_8)
        shareHtmlFile(context, file, "${conversation.title} - Merkop HTML", "Merkop Sohbetini HTML Olarak Paylaş")
    }

    fun shareStandaloneAppHtml(context: Context) {
        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportsDir, "merkop-index.html")
        context.assets.open("index.html").use { input ->
            file.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        shareHtmlFile(context, file, "Merkop Tek Dosya HTML Uygulaması", "Merkop HTML Dosyasını Paylaş")
    }

    private fun shareHtmlFile(
        context: Context,
        file: File,
        subject: String,
        chooserTitle: String
    ) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/html"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(sendIntent, chooserTitle)
        context.startActivity(chooser)
    }
}
