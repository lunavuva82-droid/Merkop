package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.MerkopMode
import com.example.data.remote.OperationType
import com.example.data.remote.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ConversationRepository(
    private val db: FirebaseFirestore
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Google hesabı ile oturum açmanız gerekiyor.")
    }

    fun observeConversations(userId: String): Flow<List<Conversation>> {
        val path = "users/$userId/conversations"
        return db.collection("users").document(userId).collection("conversations")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    Conversation::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val exceptionToLog = firestoreError ?: (error as? Exception)
                if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                    handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                }
                throw error
            }
    }

    fun observeMessages(userId: String, conversationId: String): Flow<List<ChatMessage>> {
        val path = "users/$userId/conversations/$conversationId/messages"
        return db.collection("users").document(userId)
            .collection("conversations").document(conversationId)
            .collection("messages")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    ChatMessage::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedBy { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val exceptionToLog = firestoreError ?: (error as? Exception)
                if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                    handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                }
                throw error
            }
    }

    suspend fun getConversation(userId: String, conversationId: String): Result<Conversation?> {
        val docRef = db.collection("users").document(userId)
            .collection("conversations").document(conversationId)
        return try {
            val snapshot = docRef.get().await()
            val conversation = snapshot.toObject(
                Conversation::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            Result.success(conversation)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun createConversation(
        title: String,
        mode: MerkopMode
    ): Result<String> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("conversations").document()
        val safeTitle = title.trim().ifEmpty { "Yeni Merkop Sohbeti" }.take(120)
        val payload = mapOf(
            "userId" to uid,
            "title" to safeTitle,
            "mode" to mode.id,
            "lastMessagePreview" to "",
            "messageCount" to 0L,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun addMessageAndUpdateConversation(
        conversationId: String,
        role: String,
        text: String,
        hasImage: Boolean,
        newTitleIfFirst: String?,
        newMessageCount: Long
    ): Result<String> {
        val uid = requireUserId()
        val convRef = db.collection("users").document(uid)
            .collection("conversations").document(conversationId)
        val msgRef = convRef.collection("messages").document()

        val safeText = text.trim().ifEmpty { "(Görsel mesaj)" }.take(32000)
        val preview = safeText.replace('\n', ' ').take(300)

        val msgPayload = mapOf(
            "userId" to uid,
            "conversationId" to conversationId,
            "role" to role,
            "text" to safeText,
            "hasImage" to hasImage,
            "createdAt" to FieldValue.serverTimestamp()
        )

        val convUpdate = buildMap<String, Any> {
            if (!newTitleIfFirst.isNullOrBlank()) {
                put("title", newTitleIfFirst.trim().take(120))
            }
            put("lastMessagePreview", preview)
            put("messageCount", newMessageCount.coerceIn(0L, 10000L))
            put("updatedAt", FieldValue.serverTimestamp())
        }

        return try {
            val batch = db.batch()
            batch.set(msgRef, msgPayload)
            batch.update(convRef, convUpdate)
            batch.commit().await()
            Result.success(msgRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, msgRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateConversationMode(
        conversationId: String,
        mode: MerkopMode
    ): Result<Unit> {
        val uid = requireUserId()
        val convRef = db.collection("users").document(uid)
            .collection("conversations").document(conversationId)
        return try {
            convRef.update(
                mapOf(
                    "mode" to mode.id,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, convRef.path)
            Result.failure(e)
        }
    }

    suspend fun renameConversation(
        conversationId: String,
        newTitle: String
    ): Result<Unit> {
        val uid = requireUserId()
        val convRef = db.collection("users").document(uid)
            .collection("conversations").document(conversationId)
        val safeTitle = newTitle.trim().ifEmpty { "Merkop Sohbeti" }.take(120)
        return try {
            convRef.update(
                mapOf(
                    "title" to safeTitle,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, convRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteConversation(conversationId: String): Result<Unit> {
        val uid = requireUserId()
        val convRef = db.collection("users").document(uid)
            .collection("conversations").document(conversationId)
        return try {
            val messagesSnapshot = convRef.collection("messages").get().await()
            val docs = messagesSnapshot.documents
            for (chunk in docs.chunked(400)) {
                val batch = db.batch()
                chunk.forEach { batch.delete(it.reference) }
                batch.commit().await()
            }
            convRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, convRef.path)
            Result.failure(e)
        }
    }
}
